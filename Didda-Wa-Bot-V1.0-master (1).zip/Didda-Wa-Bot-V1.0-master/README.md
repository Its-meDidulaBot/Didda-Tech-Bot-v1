<h1>Didula Wa Bot v1.0</h1>

<a href="https://github.com/Its-meDidulaBot/Didula-Whatsapp-Bot-V1"><img src="https://i.ibb.co/JnwkfJP/logo-fc681ccd.png" alt="google-font" border="0"></a>


## Setup

<div align="center">

  ### <u> Simple Method <u>

## STEP 1 👇

<div align="center">

  

  [![Run on Repl.it](https://repl.it/badge/github/quiec/whatsAlfa)](https://replit.com/@Its-meDidulaBot/Didula-bot-Qr)

## STEP 2 👇

<div align="center">

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Its-meDidulaBot/Didda-Wa-Bot-V1.0)
  ##Deploy Error You can Fix 
  1 Fork
  2 change github name & save
     

## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Lemon+milk&color=000EF7&lines=Welcome+to+Didula+WA+Bot...;Created+by+Didu....;This+is+a+Bgm+stickerbot...;With+more+features...)](https://git.io/typing-svg)

# Official Group

- [Join Oficial Whatsapp Group](https://chat.whatsapp.com/LWOdea4zvErAHkLNuAQkoP)

  gh repo clone Its-meDidulaBot/Didda-Wa-Bot-V1.0
  
  
╔═════ೋೋ═════╗

💥Boţ̧̧̧̧̧̧̧̧̧̧̧̧̧̲̲̲̲̲̲̲̲̲̲̲̲̲̥̥̥̥̯̯̯̯̯̯̯̯̯̰̰͌͌͂͂͂͂͂ ගෙන්⃟ කළ⛓️ හැකි⃟ කාර්යන් ලබා ගැනී⃞ම සදහා🦋⃝❉⃟࿔ꦿ  .menu  යොදන්න
*╚═══❖•ೋ° °ೋ•❖═══╝*
💢SUBSCRIBE ⃢MY YOU TUBE CHANEL💎⃝♡꧂ᘝᘞ : https://youtu.be/zcF0uFjIe_U
*╚═══❖•ೋ° °ೋ•❖═══╝*
🔰JOIN OUR MAIN⃤E GRUPE❤️⃟⃟◍̸̸̸̸̣̣̣❀ : https://chat.whatsapp.com/LWOdea4zvErAHkLNuAQkoP
╭━━━━━━━╮
┃       ● ══    ┃
┃███████┃
┃███████┃
┃███████┃
┃███████┃
┃███████┃
┃███████┃
┃███████┃
┃███████┃
┃         ○        ┃
╰━━━━━━━╯


💥᳆⃟ʜᷘᴜᷧɴᷢᴛⷦᴇʀꜱ™৫ ᴅɪɴɪʏᴀᜰ🛠️✾ـٰٰٰٰٖٖٖٖٜ۬ـٰٰٰٖٖٖٜ۬ـٰٰٖٖٜ۬ـٰٖٜ۬ـٰٖٜ۬ـٰٰٖٖٜ۬ـٰٰٰٖٖٖٜ۬ـٰٰٰٰٖٖٖٖٜ۬ـٰٰٰٖٖٖٜ۬ـٰٰٖٖٜ۬ـٰٖٜ۬ـٰٖٜ۬ـٰٰٖٖٜ۬ـٰٰٰٖٖٖٜ۬ـٰٰٰٰٖٖٖٖٜ۬✾➣
/﹋\
(҂`_´)
<,︻╦╤─ ҉ - -----
/﹋\.╔═════ೋೋ═════╗
